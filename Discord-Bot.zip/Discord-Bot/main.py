import discord
import random
from discord.ext import commands

# Set up the required intents
intents = discord.Intents.default()
intents.message_content = True  # Enable message content intent

# Create an instance of a bot with the command prefix '!'
bot = commands.Bot(command_prefix="!", intents=intents)

# Event: When the bot is ready and logged in
@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')

# Command: Responds to '!hello'
@bot.command()
async def hello(ctx):
    await ctx.send(f'Hello, {ctx.author.mention}!')

@bot.command()
async def ping(ctx):
    latency = bot.latency * 1000  # Convert latency to milliseconds
    await ctx.send(f'Pong! Latency is {latency:.2f}ms')

WELCOME_MESSAGES = [
    "🌸 Yay! A wild {member} appeared! Welcome to the cozy corner! 🌼✨",
    "🎉 Woohoo! {member} just landed in our server! Let's give them a warm hug! 🤗💖",
    "🌟 A new star, {member}, has joined our galaxy! Shine bright! ✨🚀",
    "🍪 Welcome, {member}! We saved you some cookies! Grab one! 🍪💕",
    "🐾 Paw-some! {member} just walked in! Let's give them a furry welcome! 🐶🐱💖",
    "🌈 Look who just arrived! {member}, welcome to our magical world! 🎠✨",
    "🎶 Ding-dong! {member} is here! Time to party! 🎊🥳",
]

# Replace with your welcome channel ID
WELCOME_CHANNEL_ID = 1228987557182963823  # Example: 123456789012345678

# Event: When a new member joins
@bot.event
async def on_member_join(member):
    channel = bot.get_channel(WELCOME_CHANNEL_ID)  # Fetch channel by ID
    if channel:
        welcome_text = random.choice(WELCOME_MESSAGES).format(member=member.mention)
        await channel.send(welcome_text)


# Run the bot with your bot token from environment variables
bot.run('MTM0NTU0NDA0MDUyMjk3NzI4MQ.GBfjz4.a60dH1d51BlP6VJRD5Lxsi3c6vX3567sVeiN_Y')